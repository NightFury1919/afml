"""
Chapter 8: Feature Importance -- runnable demonstration on the book's
synthetic dataset (getTestData). Produces the MDI / MDA / SFI importance
tables and plots, the I/R/N summary, and the orthogonal-features + weighted
Kendall's tau corroboration (snippets 8.2-8.10).

Run this under the mlfinlab env (Python 3.10.20 / sklearn 1.2.2). On newer
sklearn the float max_samples semantics differ (see the LOAD-BEARING note in
feature_importance.py) and every importance collapses to noise.

Path convention: __file__-derived repo root (this repo's .py convention).
"""
import os
import sys

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_HERE, os.pardir, os.pardir))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from ch08.feature_importance.feature_importance import (  # noqa: E402
    getTestData, featImportance, orthoFeats, get_eVec, featPCA_rank_corr,
    plotFeatImportance,
)

# --- canonical config (book defaults). Dial N_ESTIMATORS down for a faster
#     exploratory run; the I/R/N pattern is already clear by ~200 trees. ---
N_FEATURES = 40
N_INFORMATIVE = 10
N_REDUNDANT = 10
N_SAMPLES = 10000
N_ESTIMATORS = 250     # book canonical = 1000; the I/R/N pattern is clear by ~200
CV = 10
N_JOBS = 4             # this repo's convention (6 cores available)
SCORING = 'accuracy'
PCT_EMBARGO = 0.
INPUT_DATA = os.path.join(_REPO_ROOT, 'input_data')


def group_summary(imp):
    """Fraction of total (abs) importance captured by each feature type."""
    d = imp[['mean']].copy()
    d['type'] = [i[0] for i in d.index]
    frac = d['mean'].abs()
    frac = frac / frac.sum()
    return frac.groupby(d['type']).sum().reindex(['I', 'R', 'N']).round(4)


def main():
    print('Building synthetic dataset (answer key: I=informative, '
          'R=redundant, N=noise)...')
    trnsX, cont = getTestData(N_FEATURES, N_INFORMATIVE, N_REDUNDANT, N_SAMPLES)
    print(f'  trnsX {trnsX.shape}, bin balance '
          f'{cont["bin"].value_counts().to_dict()}\n')

    results = {}
    for method in ['MDI', 'MDA', 'SFI']:
        note = '  (SFI fits one bag per feature per fold -- the slow one)' \
            if method == 'SFI' else ''
        print(f'Running {method}...{note}')
        imp, oob, oos = featImportance(
            trnsX=trnsX, cont=cont, n_estimators=N_ESTIMATORS, cv=CV,
            scoring=SCORING, pctEmbargo=PCT_EMBARGO, method=method,
            n_jobs=N_JOBS)
        results[method] = (imp, oob, oos)
        print(f'  oob={oob:.4f}  oos={oos:.4f}')
        print(f'  importance by type (fraction of total): '
              f'{group_summary(imp).to_dict()}\n')

        ax = plotFeatImportance(imp, oob=oob, oos=oos, method=method,
                                tag='ch08', simNum=method)
        ax.figure.suptitle(f'{method} feature importance', y=1.02)
        plt.show()

    # --- summary table (testFunc-style) ---
    summary = pd.DataFrame(
        {m: group_summary(results[m][0]) for m in results}
    ).T
    summary['oob'] = {m: results[m][1] for m in results}
    summary['oos'] = {m: results[m][2] for m in results}
    print('=== I/R/N importance share + oob/oos by method ===')
    print(summary, '\n')

    # --- orthogonal features + weighted Kendall's tau (8.5 / 8.6) ---
    # Corroborate the (in-sample, cheap) MDI ranking against the unsupervised
    # PCA variance ranking. High positive tau => the model's important features
    # are also the high-variance PCA directions (real structure, not overfit).
    dfZ = trnsX.sub(trnsX.mean(), axis=1).div(trnsX.std(), axis=1)
    dot = pd.DataFrame(np.dot(dfZ.T, dfZ), index=trnsX.columns,
                       columns=trnsX.columns)
    eVal, eVec = get_eVec(dot, varThres=.95)
    print(f'orthoFeats: kept {eVec.shape[1]} of {trnsX.shape[1]} PCs '
          f'for 95% variance.')

    # PCA importance per original feature = weighted (by eigenvalue) squared
    # loading; rank features by it, then correlate with MDI importance.
    pca_imp = (eVec.pow(2) * eVal.values).sum(axis=1)
    pca_rank = pca_imp.rank(ascending=False)
    mdi_imp = results['MDI'][0]['mean'].reindex(pca_rank.index).fillna(0.).values
    tau = featPCA_rank_corr(mdi_imp, pca_rank.values)
    print(f'weighted Kendall tau (MDI importance vs inverse PCA rank) = '
          f'{tau:.4f}')

    # --- persist the summary (csv + pkl, per shared-artifact convention) ---
    os.makedirs(INPUT_DATA, exist_ok=True)
    summary.to_csv(os.path.join(INPUT_DATA, 'ch08_feature_importance_stats.csv'))
    summary.to_pickle(os.path.join(INPUT_DATA, 'ch08_feature_importance_stats.pkl'))
    print(f'\nSaved summary -> {INPUT_DATA}\\ch08_feature_importance_stats.'
          f'{{csv,pkl}}')
    print('(No downstream chapter consumes a ch08 pkl -- this is a record '
          'artifact, not a pipeline input.)')


if __name__ == '__main__':
    main()
